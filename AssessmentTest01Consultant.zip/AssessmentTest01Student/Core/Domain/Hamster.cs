﻿using System.Collections.Generic;

namespace AssessmentTest01.Core.Domain
{
    public class Hamster
    {
    }
}
