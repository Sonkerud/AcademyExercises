﻿namespace AssessmentTest01.Core.Domain
{
    public enum HamsterSpecie
    {
        Syrian, Campbell, WinterWhite, Roborovski
    }
}
