﻿namespace AssessmentTest01.Core.Domain
{
    public class Burrow
    {
    }
}
