﻿using System;

namespace AssessmentTest01.Core
{
    static public class Methods
    {
        public static int AddThree(int n)
        {
            throw new NotImplementedException();
        }

        public static int AddFourAndThenMultiplyByThree(int n)
        {
            throw new NotImplementedException();
        }

        public static string MaybeUppercaseAndDecorateText(string s, bool uppercase, bool decorate)
        {
            throw new NotImplementedException();
        }

        public static string TellRelationToHundred(int number)
        {
            throw new NotImplementedException();
        }


    }
}
