
using AssessmentTest01.Core.Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace AssessmentTest01.Tests
{
    [TestClass]
    public class Level2Tests
    {
        [TestMethod]
        public void a_pet_hamster_who_dont_like_food()
        {
            throw new NotImplementedException();
            //var h = new Hamster("Maximilian", true, HamsterSpecie.Campbell);
            //string result = h.Description();
            //Assert.AreEqual("Maximilian is a pet Campbell hamster. Maximilian doesn't like any food.", result);
        }

        [TestMethod]
        public void a_pet_hamster_who_likes_three_types_of_food()
        {
            throw new NotImplementedException();
            //var h = new Hamster("Dexter", true, HamsterSpecie.Syrian);
            //h.LikesFood = new List<string> {"seeds", "fruits", "insects" };
            //string result = h.Description();
            //Assert.AreEqual("Dexter is a pet Syrian hamster. Dexter likes 3 types of food.", result);
        }

        [TestMethod]
        public void a_pet_hamster_who_likes_two_types_of_food()
        {
            throw new NotImplementedException();
            //var h = new Hamster("Chiquita", true, HamsterSpecie.Roborovski);
            //h.LikesFood = new List<string> { "fruits", "insects" };
            //string result = h.Description();
            //Assert.AreEqual("Chiquita is a pet Roborovski hamster. Chiquita likes 2 types of food.", result);
        }

        [TestMethod]
        public void a_wild_hamster_who_likes_one_type_of_food()
        {
            throw new NotImplementedException();
            //var h = new Hamster("Goldilocks", false, HamsterSpecie.WinterWhite);
            //h.LikesFood = new List<string> { "insects" };
            //string result = h.Description();
            //// Info to student: note that we expect "type" instead of "types"
            //Assert.AreEqual("Goldilocks is a wild WinterWhite hamster. Goldilocks likes 1 type of food.", result);
        }

        // Create a new constructor so the following test will pass
        // The new constructor should give some default data for the hamster (a winterwhite wild hamster who likes insects)
        [TestMethod]
        public void a_hamster_created_with_alternative_constructor()
        {
            throw new NotImplementedException();

            //var b = new Burrow(10.77, 20.55);

            //var h = new Hamster("Jojo", b);

            //string position = h.GetBurrowPosition();
            //Assert.AreEqual("Jojo has a burrow at longitude 10.77 and latitude 20.55", position);

            //Assert.IsFalse(h.IsPet);

            //Assert.AreEqual("Jojo is a wild WinterWhite hamster. Jojo likes 1 type of food.", h.Description());

            //Assert.AreEqual(1, h.LikesFood.Count);
            //Assert.AreEqual("insects", h.LikesFood[0]);

            //// Now Jojo don't have a burrow anymore
            //h.Burrow = null;

            //Assert.AreEqual("Jojo doesn't have a burrow", h.GetBurrowPosition());
        }

    }
}
