
using AssessmentTest01.Core;
using AssessmentTest01.Core.Domain;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace AssessmentTest01.Tests
{
    [TestClass]
    public class Level1Tests
    {
        // Warm up (give this solution to the students)
        [TestMethod]
        public void warm_up()
        {
            int result = Methods.AddThree(5);
            Assert.AreEqual(8, result);
        }

        // Warm up (give this solution to the students)
        [TestMethod]
        [DataRow(0, 3)]   // 0 + 3 = 3
        [DataRow(5, 8)]   // 5 + 3 = 8
        [DataRow(10, 13)] // 10 + 3 = 13
        public void warm_up_with_datarows(int number, int expected)
        {
            int result = Methods.AddThree(number);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        [DataRow(0, 12)] // 4 * 3 = 12
        [DataRow(1, 15)] // 5 * 3 = 15
        [DataRow(5, 27)] // 9 * 3 = 27
        public void add_four_and_then_multiply_by_three(int number, int expected)
        {
            int result = Methods.AddFourAndThenMultiplyByThree(number);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        [DataRow("aaa", true, true, "-:AAA:-")]
        [DataRow("aaa", true, false, "AAA")]
        [DataRow("aaa", false, true, "-:aaa:-")]
        [DataRow("aaa", false, false, "aaa")]
        public void maybe_uppercase_and_decorate_text(string s, bool toupper, bool decoration, string expected)
        {
            string result = Methods.MaybeUppercaseAndDecorateText(s, toupper, decoration);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        [DataRow(-5555, "-5555 is a negative number")]
        [DataRow(-1, "-1 is a negative number")]
        [DataRow(92, "Add 8 to 92 and you get 100")]
        [DataRow(95, "Add 5 to 95 and you get 100")]
        [DataRow(100, "Add 0 to 100 and you get 100")]
        [DataRow(101, "101 is greater than 100")]
        [DataRow(4444, "4444 is greater than 100")]
        public void tell_relation_to_the_number_100(int number, string expected)
        {
            string result = Methods.TellRelationToHundred(number);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void a_pet_roborovski_hamster()
        {
            throw new NotImplementedException();

            //var h = new Hamster("Nemo", true, HamsterSpecie.Roborovski);

            //string result = h.Greet();
            //Assert.AreEqual("Nemo is a pet Roborovski hamster.", result);
        }

        [TestMethod]
        public void a_wild_syrian_hamster()
        {
            throw new NotImplementedException();
            //var h = new Hamster("Kernel", false, HamsterSpecie.Syrian);

            //string result = h.Greet();
            //Assert.AreEqual("Kernel is a wild Syrian hamster.", result);

        }
    }
}
